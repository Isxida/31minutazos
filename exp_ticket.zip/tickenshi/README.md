# Tickenshi

Abre `/tickenshi` o `/tickenshi/` con la aplicación iniciada. El controlador solo entrega la vista; las respuestas nunca se envían al servidor.

El cuestionario y el ticket usan HTML, CSS y JavaScript sin dependencias. Los recursos se sirven desde `/tickenshi/assets/`. El ticket se recrea con elementos HTML: no carga ni modifica los PDF.

Los precios de `assets/model.js` se transcribieron de `static/tickets/KenshiPrecios.png`: A 3708; B 3286; C y PCD 2666; DD 1984 o 1389; D 1711 o 992, en MXN. La zona determina las opciones del último paso. Los cargos por servicio ya están incluidos; el cargo por procesamiento de orden de $50 de la imagen no se suma al precio individual del recuerdo. La fecha, el recinto y los datos fijos se tomaron de las referencias proporcionadas.

El paso de sección usa una lista vertical desplazable con selección nativa, compatible con ratón, táctil y teclado. Sus opciones dependen de la zona y se validan también al recuperar datos locales:

| Zona | Secciones únicas del mapa | Cantidad |
| --- | --- | --- |
| A | A1–A13 | 13 |
| B | B1–B8 | 8 |
| C | C3–C18 | 16 |
| DD | DD4–DD13 y DD24–DD33 | 20 |
| D | D14–D23 | 10 |
| PCD | PCD, sin número | 1 |

Las etiquetas se transcribieron del mapa proporcionado en el chat; A1 y A9 aparecen repetidas en el dibujo, pero son opciones únicas. Se incluyen las etiquetas grises como secciones del recinto; el color no se interpreta como disponibilidad de entradas. El anillo exterior E/EE queda excluido porque no tiene una zona ni tarifa en el catálogo solicitado. No se infieren filas, asientos ni disponibilidad del mapa.

Cambiar de zona limpia la sección y la tarifa anteriores. Los tickets antiguos con secciones incompatibles se conservan en la colección, se marcan “por corregir” y vuelven al selector al abrirlos. Solo se pueden guardar y exportar después de completar una sección válida.

`localStorage` conserva el borrador (`tickenshi.draft.v1`) y la colección (`tickenshi.tickets.v1`). Se pueden revisar y editar los tickets desde “Mis tickets”. Los datos pertenecen al navegador y al origen; al cambiar de dominio, usar otro dispositivo o borrar los datos del sitio, la colección no se transfiere. Si el navegador bloquea el almacenamiento, la interfaz avisa y no confirma un guardado fallido.

El azul #024DDF y la familia Averta siguen la referencia visual de Ticketmaster México. Las dos fuentes se solicitan a su CDN público; sin conexión se usa Helvetica/Arial. No hay analítica, solicitudes de precios ni API de datos.

Los dos códigos decorativos usan las iniciales del nombre, zona, sección, fila, asiento y una suma determinista. Siempre comienzan con FAN. La marca “FAN MADE · SIN VALIDEZ” permanece en el diseño.

“Descargar PNG” aparece al terminar el cuestionario y al abrir un ticket guardado. Exporta solo el boleto, sin la interfaz ni la sombra exterior, a 1600 píxeles de ancho. Conserva los datos y la marca fan made. La imagen se genera en el navegador con SVG y canvas, sin bibliotecas ni envío de datos al servidor. Las fuentes se incrustan si el CDN está disponible; sin conexión se usan las fuentes de respaldo.

“Entrada en 3D” aparece junto a “Descargar PNG” y abre un diálogo con el mismo ticket en 3D, hecho con CSS (`perspective`, `preserve-3d` y caras con `backface-visibility: hidden`) y sin bibliotecas. Tiene timbre perforado con brillo holográfico, lomo y talón, cada uno con frente y reverso. Usa los datos del ticket abierto y el sello “RECUERDO” aparece cuando están completos. El ticket se balancea solo y con ratón se inclina hacia el puntero. Al arrastrarlo gira y se asienta en la cara más cercana. Clic, Enter o “Voltear” lo voltean, y “Pausar” detiene el balanceo y el video. Con `prefers-reduced-motion` empieza en pausa. Todo vive en `assets/ticket3d.js` y `assets/ticket3d.css`; las clases llevan el prefijo `t3-` para no tocar el ticket 2D ni su exportación.

“Cambia la imagen” elige la foto del timbre entre los archivos de `static/images/hachi/`, servidos en `/tickenshi/images/` para que también carguen desde el subdominio de Tickenshi. La elección se guarda en `tickenshi.photo3d.v1`. Las fotos y el video solo se descargan la primera vez que se abre el diálogo. `/ticketazo` redirige aquí.

Comprobaciones desde la raíz del repositorio:

```text
node --test src/test/js/tickenshi.test.cjs
node --test src/test/js/tickenshi-export.test.cjs
node --test src/test/js/tickenshi-3d.test.cjs
mvn -q -Dtest=TickenshiControllerTest test
```

Vista previa independiente, sin arrancar Spring:

```text
python -m http.server 8788 --bind 127.0.0.1 --directory src/main/resources/templates
```

Abre `http://127.0.0.1:8788/tickenshi/`. Su almacenamiento será independiente del de la aplicación, porque el puerto forma parte del origen. Las fotos de la entrada en 3D no cargan ahí: `/tickenshi/images/` lo resuelve Spring.
