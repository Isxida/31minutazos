/* Prices transcribed from tickets/KenshiPrecios.png. Both unlabeled DD/D tariffs are selectable. */
(function (root) {
    'use strict';
    const range = (prefix, first, last) => Object.freeze(Array.from({ length: last - first + 1 }, (_, index) => `${prefix}${first + index}`));
    // Unique section labels from the supplied venue map; E/EE are outside the priced catalog.
    const ZONES = Object.freeze({
        A: Object.freeze({ prices: Object.freeze([3708]), color: '#4940d5', sections: range('A', 1, 13) }),
        B: Object.freeze({ prices: Object.freeze([3286]), color: '#ee237e', sections: range('B', 1, 8) }),
        C: Object.freeze({ prices: Object.freeze([2666]), color: '#edb72c', sections: range('C', 3, 18) }),
        DD: Object.freeze({ prices: Object.freeze([1984, 1389]), color: '#04bce4', sections: Object.freeze([...range('DD', 4, 13), ...range('DD', 24, 33)]) }),
        D: Object.freeze({ prices: Object.freeze([1711, 992]), color: '#00cbbf', sections: range('D', 14, 23) }),
        PCD: Object.freeze({ prices: Object.freeze([2666]), color: '#b2d0e9', sections: Object.freeze(['PCD']) })
    });
    const FIELDS = ['name', 'zone', 'section', 'row', 'seat', 'price'];
    function normalize(field, value) {
        const text = String(value ?? '').trim();
        if (field === 'name') return text.replace(/\s+/g, ' ');
        return ['zone', 'section', 'row'].includes(field) ? text.toUpperCase() : text;
    }
    function error(field, value, data = {}) {
        const text = normalize(field, value);
        switch (field) {
            case 'name': return /^[\p{L}\p{M}]+(?:[ '\u2019-][\p{L}\p{M}]+)*$/u.test(text) && text.length <= 80 ? '' : 'Escribe tus nombres (hasta 80 caracteres; letras, espacios, apóstrofos o guiones).';
            case 'zone': return Object.hasOwn(ZONES, text) ? '' : 'Elige una zona: A, B, C, DD, D o PCD.';
            case 'section': return Object.hasOwn(ZONES, data.zone) && ZONES[data.zone].sections.includes(text) ? '' : 'Elige una sección del mapa que corresponda a tu zona.';
            case 'row': return /^[A-Z]$/.test(text) ? '' : 'La fila debe ser una sola letra de A a Z.';
            case 'seat': return /^\d{1,2}$/.test(text) && Number(text) >= 1 ? '' : 'El asiento debe ser un número del 1 al 99.';
            case 'price': return Object.hasOwn(ZONES, data.zone) && ZONES[data.zone].prices.includes(Number(text)) ? '' : 'Elige una de las tarifas disponibles para tu zona.';
            default: return 'Campo desconocido.';
        }
    }
    function clean(raw = {}) {
        if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
        const data = {};
        for (const field of FIELDS) {
            const value = normalize(field, raw[field]);
            if (value && !error(field, value, data)) data[field] = field === 'price' ? Number(value) : value;
        }
        return data;
    }
    function complete(data) { return FIELDS.every(field => !error(field, data[field], data)); }
    function restoreTicket(raw) {
        if (!raw || typeof raw.id !== 'string' || !/^[a-zA-Z0-9-]{1,80}$/.test(raw.id)) return null;
        const data = clean(raw.data);
        if (FIELDS.some(field => field !== 'section' && error(field, data[field], data))) return null;
        // Keep old incompatible sections visible until the owner corrects them, instead of dropping saved tickets.
        if (!data.section && typeof raw.data?.section === 'string') data.section = normalize('section', raw.data.section).slice(0, 12);
        return { id: raw.id, data };
    }
    function code(data) {
        const name = normalize('name', data.name).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase();
        const initials = name.split(/[ '\u2019-]+/).map(part => part[0] || '').join('').replace(/[^A-Z]/g, '').slice(0, 5) || 'KY';
        const source = FIELDS.slice(0, 5).map(field => normalize(field, data[field])).join('|');
        let hash = 2166136261;
        for (const char of source) hash = Math.imul(hash ^ char.codePointAt(0), 16777619) >>> 0;
        return `FAN-${initials}-${data.zone || 'X'}${data.section || 'X0'}${data.row || 'X'}${String(data.seat || '0').padStart(2, '0')}-${String(hash % 10000).padStart(4, '0')}`;
    }
    const api = { ZONES, FIELDS, normalize, error, clean, complete, restoreTicket, code };
    if (typeof module !== 'undefined' && module.exports) module.exports = api;
    else root.Tickenshi = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
