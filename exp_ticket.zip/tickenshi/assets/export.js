(() => {
    'use strict';
    let embeddedFonts;
    function dataUrl(blob) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.onerror = () => reject(reader.error);
            reader.readAsDataURL(blob);
        });
    }
    function fonts() {
        if (!embeddedFonts) {
            const faces = [];
            for (const sheet of document.styleSheets) {
                try {
                    for (const rule of sheet.cssRules) {
                        if (rule.type !== CSSRule.FONT_FACE_RULE) continue;
                        const source = rule.style.getPropertyValue('src').match(/url\(["']?([^"')]+)["']?\)/);
                        if (!source) continue;
                        faces.push((async () => {
                            try {
                                const response = await fetch(new URL(source[1], sheet.href || document.baseURI), { signal: AbortSignal.timeout(5000) });
                                if (!response.ok) return '';
                                const embedded = await dataUrl(await response.blob());
                                return rule.cssText.replace(source[1], embedded);
                            } catch { return ''; } // Use the same system-font fallback as the page when offline.
                        })());
                    }
                } catch { /* Cross-origin stylesheets cannot be read; system fonts remain available. */ }
            }
            embeddedFonts = Promise.all(faces).then(rules => rules.join('\n'));
        }
        return embeddedFonts;
    }
    async function png(ticket) {
        ticket.getAnimations({ subtree: true }).forEach(animation => animation.finish());
        const width = ticket.offsetWidth;
        const height = ticket.offsetHeight;
        if (!width || !height) throw new Error('El ticket no está visible.');
        const clone = ticket.cloneNode(true);
        // Resolve container units and inherited styles before isolating the ticket from the page.
        const originals = [ticket, ...ticket.querySelectorAll('*')];
        const copies = [clone, ...clone.querySelectorAll('*')];
        originals.forEach((original, index) => {
            const computed = getComputedStyle(original);
            for (const property of computed) copies[index].style.setProperty(property, computed.getPropertyValue(property));
            copies[index].style.animation = 'none';
            copies[index].style.transition = 'none';
            copies[index].removeAttribute('id');
        });
        clone.style.transform = 'none';
        clone.style.boxShadow = 'none';
        clone.style.margin = '0';
        clone.style.width = `${width}px`;
        clone.style.height = `${height}px`;
        const fontCss = await fonts();
        const wrapper = document.createElementNS('http://www.w3.org/1999/xhtml', 'div');
        const style = document.createElementNS('http://www.w3.org/1999/xhtml', 'style');
        style.textContent = fontCss;
        wrapper.append(style, clone);
        const html = new XMLSerializer().serializeToString(wrapper);
        const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}"><foreignObject width="100%" height="100%">${html}</foreignObject></svg>`;
        const image = new Image();
        image.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
        await image.decode();
        const canvas = document.createElement('canvas');
        const scale = 1600 / width;
        canvas.width = 1600;
        canvas.height = Math.ceil(height * scale);
        const context = canvas.getContext('2d');
        if (!context) throw new Error('El navegador no permite generar la imagen.');
        context.drawImage(image, 0, 0, canvas.width, canvas.height);
        return new Promise((resolve, reject) => canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error('No se pudo generar el PNG.')), 'image/png'));
    }
    window.TickenshiExport = { png };
})();
