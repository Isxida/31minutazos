(() => {
    'use strict';
    const M = window.Tickenshi;
    const $ = selector => document.querySelector(selector);
    const money = value => new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN', maximumFractionDigits: 0 }).format(value);
    const DRAFT_KEY = 'tickenshi.draft.v1';
    const TICKETS_KEY = 'tickenshi.tickets.v1';
    const labels = ['TU NOMBRE', 'TU ZONA', 'TU SECCIÓN', 'TU FILA', 'TU ASIENTO', 'TU TARIFA'];
    const questions = [
        ['¿Cómo te llamas?', 'Tus nombres darán un toque único a los dos códigos de tu ticket.', 'Tus nombres', 80],
        ['¿Desde dónde lo vas a vivir?', 'Elige una de las seis zonas de la referencia. Precios en MXN.'],
        ['¿Cuál es tu sección?', 'Desliza la lista y elige una sección de tu zona.'],
        ['¿En qué fila estarás?', 'Una sola letra, de la A a la Z.', 'Ej. F', 1],
        ['¿Y tu asiento?', 'Tu lugar en este recuerdo: un número del 1 al 99.', 'Ej. 24', 2],
        ['El último detalle: tu tarifa.', 'El precio corresponde a tu zona e incluye cargos por servicio, según la referencia.']
    ];
    let storageWarning = '';
    let collectionReadable = true;
    function read(key, fallback) {
        try { const raw = localStorage.getItem(key); return raw === null ? fallback : JSON.parse(raw); }
        catch (e) {
            storageWarning = 'No se pudieron leer los datos locales. Puedes crear tu ticket; el guardado podría no estar disponible.';
            if (key === TICKETS_KEY) collectionReadable = false;
            return fallback;
        }
    }
    function write(key, value) {
        try { localStorage.setItem(key, JSON.stringify(value)); return true; }
        catch (e) { storageWarning = 'El navegador no permite guardar ahora. Tu ticket sigue visible, pero podrías perderlo al cerrar.'; return false; }
    }
    function storageStatus() { $('#storage-status').textContent = storageWarning || 'Tu borrador se guarda en este navegador.'; }
    const storedTickets = read(TICKETS_KEY, []);
    if (!Array.isArray(storedTickets)) { collectionReadable = false; storageWarning = 'La colección local tiene un formato desconocido. No se sobrescribirá.'; }
    let tickets = (Array.isArray(storedTickets) ? storedTickets : []).map(M.restoreTicket).filter(Boolean);
    const draft = read(DRAFT_KEY, null);
    let state = { data: M.clean(draft?.data), step: 0, id: typeof draft?.id === 'string' && tickets.some(t => t.id === draft.id) ? draft.id : null };
    const firstMissing = M.FIELDS.findIndex(field => M.error(field, state.data[field], state.data));
    state.step = Math.min(Number.isInteger(draft?.step) ? Math.max(0, draft.step) : 0, firstMissing < 0 ? 6 : firstMissing);
    if (state.step === 6 && !state.id) state.step = 5;
    let busy = false;
    let toastTimer;
    const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
    function persistDraft() { write(DRAFT_KEY, { data: state.data, step: state.step, id: state.id }); storageStatus(); }
    function toast(message) { $('#toast').textContent = message; $('#toast').classList.add('visible'); clearTimeout(toastTimer); toastTimer = setTimeout(() => $('#toast').classList.remove('visible'), 3500); }
    function updateCount() { $('#ticket-count').textContent = String(tickets.length); }
    function preview(changed) {
        const data = M.clean(state.data);
        const values = { ...data, price: data.price ? money(data.price) : '—', code: data.name ? M.code(data) : 'FAN-KY · TU RECUERDO' };
        $('#ticket').querySelectorAll('[data-value]').forEach(el => { el.textContent = values[el.dataset.value] || '—'; });
        $('#ticket').querySelectorAll('[data-highlight]').forEach(el => {
            el.classList.toggle('is-current', el.dataset.highlight === M.FIELDS[state.step]);
            if (changed && (el.dataset.highlight === changed || (el.dataset.highlight === 'name' && data.name))) {
                el.classList.remove('is-updated'); void el.offsetWidth; el.classList.add('is-updated');
            }
        });
        $('#ticket-holder').style.setProperty('--zone-color', M.ZONES[data.zone]?.color || '#024ddf');
    }
    function choice(value, content, name, checked) {
        const label = document.createElement('label'); label.className = 'choice';
        const input = document.createElement('input'); input.type = 'radio'; input.name = name; input.value = value; input.checked = checked;
        input.setAttribute('aria-describedby', 'question-help field-error');
        const body = document.createElement('span'); body.className = 'choice-body'; body.innerHTML = content;
        label.append(input, body); return label;
    }
    function render(focus = true) {
        const panel = $('#question-panel'); panel.replaceChildren(); panel.style.animation = 'none'; void panel.offsetWidth; panel.style.animation = '';
        $('#field-error').textContent = '';
        $('#step-counter').textContent = state.step === 6 ? '06 / 06' : `${String(state.step + 1).padStart(2, '0')} / 06`;
        $('#step-label').textContent = state.step === 6 ? 'TU RECUERDO' : labels[state.step];
        $('#progress-fill').style.width = `${state.step / 6 * 100}%`;
        $('.progress-track').setAttribute('aria-valuenow', state.step);
        $('#back').hidden = state.step === 0 || state.step === 6;
        $('.form-actions').hidden = state.step === 6;
        if (state.step === 6) {
            panel.innerHTML = '<div class="saved-icon" aria-hidden="true">✓</div><h2 id="question-title" tabindex="-1">Tu recuerdo está listo.</h2><p class="question-help" id="question-help">Cada detalle cuenta. Puedes volver a encontrarlo en Mis tickets.</p><div class="summary"></div><div class="finish-actions"><button class="primary-button" type="button" id="download-png">Descargar PNG <span aria-hidden="true">↓</span></button><button class="ticket3d-button" type="button" id="open-3d">Entrada en 3D <span aria-hidden="true">✦</span></button><button class="back-button new-ticket-button" type="button" id="finish-new">Crear otro</button><button class="text-button" type="button" id="edit-ticket">Editar este ticket</button></div>';
            for (const text of [state.data.name, `Zona ${state.data.zone}`, `Sección ${state.data.section}`, `Fila ${state.data.row}`, `Asiento ${state.data.seat}`, `${money(state.data.price)} MXN`]) { const tag = document.createElement('span'); tag.textContent = text; panel.querySelector('.summary').append(tag); }
            $('#finish-new').addEventListener('click', startNew);
            $('#download-png').addEventListener('click', downloadPng);
            $('#open-3d').addEventListener('click', () => window.TickenshiTicket3D.open(state.data));
            $('#edit-ticket').addEventListener('click', () => { state.step = 0; persistDraft(); render(); });
        } else {
            const [title, help, placeholder, maxLength] = questions[state.step];
            panel.innerHTML = '<h2 id="question-title" tabindex="-1"></h2><p class="question-help" id="question-help"></p>';
            $('#question-title').textContent = title; $('#question-help').textContent = help;
            const field = M.FIELDS[state.step];
            if (field === 'zone') {
                const group = document.createElement('div'); group.className = 'zone-options'; group.setAttribute('role', 'radiogroup'); group.setAttribute('aria-labelledby', 'question-title');
                for (const [zone, config] of Object.entries(M.ZONES)) {
                    const item = choice(zone, `<span class="zone-swatch" style="--swatch:${config.color}"></span><span class="choice-name">${zone}</span><span class="choice-price">${config.prices.length > 1 ? 'desde ' : ''}${money(Math.min(...config.prices))}</span>`, field, state.data.zone === zone);
                    group.append(item);
                }
                panel.append(group);
            } else if (field === 'section') {
                const sections = M.ZONES[state.data.zone].sections;
                $('#question-help').textContent = `Zona ${state.data.zone} · ${sections.length} ${sections.length === 1 ? 'sección disponible' : 'secciones disponibles'}. Desliza o usa las flechas para elegir.`;
                const select = document.createElement('select');
                select.id = 'answer'; select.name = field; select.className = 'section-select'; select.size = sections.length === 1 ? 1 : 5;
                select.setAttribute('aria-labelledby', 'question-title');
                select.setAttribute('aria-describedby', 'question-help field-error');
                for (const section of sections) {
                    const option = document.createElement('option'); option.value = section; option.textContent = section; select.append(option);
                }
                select.value = sections.includes(state.data.section) ? state.data.section : sections[0];
                state.data.section = select.value;
                panel.append(select);
                persistDraft();
            } else if (field === 'price') {
                const prices = M.ZONES[state.data.zone].prices;
                if (prices.length === 1) {
                    state.data.price = prices[0];
                    const display = document.createElement('div'); display.className = 'automatic-price'; display.innerHTML = `<span>Zona ${state.data.zone}<br>Tarifa de la referencia</span><strong>${money(prices[0])} <small style="font-size:12px">MXN</small></strong>`; panel.append(display);
                } else {
                    $('#question-help').textContent = `La zona ${state.data.zone} tiene dos precios en la referencia. Elige uno para tu ticket; la imagen no especifica categorías.`;
                    const group = document.createElement('div'); group.className = 'price-options'; group.setAttribute('role', 'radiogroup'); group.setAttribute('aria-labelledby', 'question-title');
                    prices.forEach(price => group.append(choice(String(price), `<span class="choice-name">${money(price)} <small>MXN</small></span><span class="price-description">Zona ${state.data.zone} · servicio incluido</span>`, field, Number(state.data.price) === price)));
                    panel.append(group);
                }
            } else {
                const input = document.createElement('input'); input.type = 'text'; input.id = 'answer'; input.name = field; input.className = 'text-input'; input.placeholder = placeholder; input.maxLength = maxLength; input.value = state.data[field] || '';
                input.setAttribute('aria-labelledby', 'question-title'); input.setAttribute('aria-describedby', 'question-help field-error'); input.autocomplete = field === 'name' ? 'given-name' : 'off';
                if (field === 'seat') input.inputMode = 'numeric';
                else if (field !== 'name') input.autocapitalize = 'characters';
                input.spellcheck = field === 'name'; panel.append(input);
            }
            $('#next').innerHTML = state.step === 5 ? 'Guardar mi ticket <span aria-hidden="true">↗</span>' : 'Continuar <span aria-hidden="true">↗</span>';
        }
        preview(); storageStatus();
        if (focus) (panel.querySelector('input[type=text], select') || panel.querySelector('#question-title')).focus({ preventScroll: true });
    }
    function updateAnswer(target) {
        const field = M.FIELDS[state.step];
        if (!field || target.name !== field) return;
        const value = M.normalize(field, target.value);
        if (field === 'zone' && state.data.zone !== value) { delete state.data.price; delete state.data.section; }
        state.data[field] = field === 'price' ? Number(value) : value;
        if (['section', 'row'].includes(field)) target.value = value;
        $('#field-error').textContent = ''; target.removeAttribute('aria-invalid');
        preview(field); persistDraft();
    }
    $('#question-panel').addEventListener('input', event => { if (event.target.matches('input[type=text]')) updateAnswer(event.target); });
    $('#question-panel').addEventListener('change', event => { if (event.target.matches('input[type=radio], select')) updateAnswer(event.target); });
    async function transition(step) {
        busy = true; $('#next').disabled = true; $('#back').disabled = true;
        try {
            if (!reducedMotion.matches && $('#question-panel').animate) await $('#question-panel').animate([{ opacity: 1, transform: 'translateY(0)' }, { opacity: 0, transform: 'translateY(-10px)' }], { duration: 150, easing: 'ease-in' }).finished;
            state.step = step; persistDraft(); render();
        } finally { busy = false; $('#next').disabled = false; $('#back').disabled = false; }
    }
    $('#question-form').addEventListener('submit', async event => {
        event.preventDefault(); if (busy || state.step === 6) return;
        const field = M.FIELDS[state.step]; const message = M.error(field, state.data[field], state.data);
        if (message) { $('#field-error').textContent = message; const input = $('#question-panel input, #question-panel select'); input?.setAttribute('aria-invalid', 'true'); input?.focus(); return; }
        state.data[field] = M.normalize(field, state.data[field]);
        if (field === 'price') {
            state.data = M.clean(state.data);
            if (!M.complete(state.data)) { const missing = M.FIELDS.findIndex(key => M.error(key, state.data[key], state.data)); await transition(missing); return; }
            if (!collectionReadable) { toast('No se puede sobrescribir la colección porque no se pudo leer. Tu borrador sigue disponible.'); return; }
            const id = state.id || (crypto.randomUUID ? crypto.randomUUID() : Array.from(crypto.getRandomValues(new Uint8Array(16)), b => b.toString(16).padStart(2, '0')).join(''));
            const record = { id, data: { ...state.data } };
            const nextTickets = tickets.some(t => t.id === id) ? tickets.map(t => t.id === id ? record : t) : [...tickets, record];
            if (!write(TICKETS_KEY, nextTickets)) { storageStatus(); toast('No se pudo guardar. Conserva esta pestaña abierta e inténtalo otra vez.'); return; }
            tickets = nextTickets; state.id = id; updateCount(); await transition(6);
            $('#ticket').classList.remove('ticket-ready'); void $('#ticket').offsetWidth; $('#ticket').classList.add('ticket-ready'); toast('Tu ticket ya está en Mis tickets.');
        } else await transition(state.step + 1);
    });
    $('#back').addEventListener('click', () => { if (!busy && state.step > 0) transition(state.step - 1); });
    function startNew() { state = { data: {}, step: 0, id: null }; persistDraft(); render(); }
    async function downloadPng(event) {
        const button = event.currentTarget;
        const label = button.innerHTML;
        const filename = `tickenshi-${M.code(state.data)}.png`;
        button.disabled = true;
        button.textContent = 'Generando PNG…';
        button.setAttribute('aria-busy', 'true');
        try {
            const blob = await window.TickenshiExport.png($('#ticket'));
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url; link.download = filename;
            document.body.append(link); link.click(); link.remove();
            setTimeout(() => URL.revokeObjectURL(url), 30000);
            toast('PNG generado. La descarga está lista.');
        } catch {
            toast('No se pudo generar el PNG. Inténtalo otra vez en un navegador actualizado.');
        } finally {
            button.disabled = false;
            button.innerHTML = label;
            button.removeAttribute('aria-busy');
        }
    }
    $('#new-ticket').addEventListener('click', () => { $('#collection-dialog').close(); startNew(); });
    $('#open-collection').addEventListener('click', () => {
        const list = $('#collection-list'); list.replaceChildren();
        if (!tickets.length) { const empty = document.createElement('p'); empty.className = 'empty-collection'; empty.textContent = 'Aquí empieza tu colección. Crea tu primer recuerdo.'; list.append(empty); }
        [...tickets].reverse().forEach(record => {
            const card = document.createElement('article'); card.className = 'saved-card'; card.style.setProperty('--zone-color', M.ZONES[record.data.zone].color);
            const info = document.createElement('div'); const title = document.createElement('h3'); title.textContent = record.data.name;
            const needsSection = !!M.error('section', record.data.section, record.data);
            const detail = document.createElement('p'); detail.textContent = `Zona ${record.data.zone} · Sección ${record.data.section || 'pendiente'}${needsSection ? ' (por corregir)' : ''} · Fila ${record.data.row} · Asiento ${record.data.seat}`;
            const price = document.createElement('p'); price.textContent = `${money(record.data.price)} MXN · FAN MADE`;
            info.append(title, detail, price); const open = document.createElement('button'); open.type = 'button'; open.textContent = needsSection ? 'Corregir sección ↗' : 'Ver ticket ↗'; open.setAttribute('aria-label', `${needsSection ? 'Corregir' : 'Ver'} ticket de ${record.data.name}`);
            open.addEventListener('click', () => { state = { data: M.clean(record.data), id: record.id, step: needsSection ? 2 : 6 }; persistDraft(); render(); $('#collection-dialog').close(); $('#question-title').focus({ preventScroll: true }); });
            card.append(info, open); list.append(card);
        });
        $('#collection-dialog').showModal();
    });
    $('#zoom').addEventListener('click', () => { const clone = $('#ticket').cloneNode(true); clone.removeAttribute('id'); clone.classList.remove('ticket-ready'); clone.querySelectorAll('.is-updated,.is-current').forEach(el => el.classList.remove('is-updated', 'is-current')); $('#zoom-content').replaceChildren(clone); $('#zoom-dialog').showModal(); });
    document.querySelectorAll('[data-close]').forEach(button => button.addEventListener('click', () => button.closest('dialog').close()));
    document.querySelectorAll('dialog').forEach(dialog => dialog.addEventListener('click', event => { if (event.target === dialog) { const bounds = dialog.getBoundingClientRect(); if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) dialog.close(); } }));
    // Refresh another tab's collection before a save can overwrite its latest changes.
    window.addEventListener('storage', event => { if (event.key === TICKETS_KEY) { const latest = read(TICKETS_KEY, []); if (Array.isArray(latest)) { tickets = latest.map(M.restoreTicket).filter(Boolean); updateCount(); } else collectionReadable = false; } });
    updateCount(); render(false);
})();
