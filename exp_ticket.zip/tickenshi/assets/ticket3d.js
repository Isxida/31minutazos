/* "Entrada en 3D": a stamp-and-stub ticket built with CSS 3D inside a dialog. Pure helpers are exported for tests. */
(function (root) {
    'use strict';
    // Served from static/images/hachi through /tickenshi/images/** so the tickenshi subdomain can reach them.
    // Focal points keep the face inside the nearly square stamp window.
    const PHOTOS = Object.freeze([
        Object.freeze({ id: 'video', type: 'video', src: '/tickenshi/images/kenshi.mp4', label: 'En movimiento', position: '50% 30%' }),
        Object.freeze({ id: 'kenshi2', type: 'image', src: '/tickenshi/images/kenshi2.jpg', label: 'Cielo azul', position: '50% 28%' }),
        Object.freeze({ id: 'kenshi3', type: 'image', src: '/tickenshi/images/kenshi3.jpg', label: 'Retrato', position: '50% 30%' }),
        Object.freeze({ id: 'kenshi4', type: 'image', src: '/tickenshi/images/kenshi4.jpg', label: 'Atardecer', position: '42% 18%' }),
        Object.freeze({ id: 'kenshi5', type: 'image', src: '/tickenshi/images/kenshi5.jpg', label: 'Rojo', position: '50% 32%' }),
        Object.freeze({ id: 'kenshi6', type: 'image', src: '/tickenshi/images/kenshi6.jpg', label: 'Tiburón', position: '58% 26%' }),
        Object.freeze({ id: 'doodle', type: 'doodle', src: '/tickenshi/images/img.png', label: 'Garabato', position: '50% 50%' })
    ]);
    const PHOTO_KEY = 'tickenshi.photo3d.v1';
    const DEFAULT_COLOR = '#024ddf';
    function photo(id) { return PHOTOS.find(item => item.id === id) || PHOTOS[0]; }
    // Alternating bar and gap widths (bar first) between fixed guards; decorative, not a real symbology.
    function barcode(code) {
        let hash = 2166136261;
        for (const char of String(code ?? '')) hash = Math.imul(hash ^ char.codePointAt(0), 16777619) >>> 0;
        const widths = [1, 1, 1, 1];
        for (let index = 0; index < 36; index++) {
            hash = Math.imul(hash ^ (hash >>> 15), 2246822519) >>> 0;
            widths.push(1 + (hash % 3), 1 + ((hash >>> 8) % 2));
        }
        widths.push(1, 1, 1);
        return widths;
    }
    // White text only where the zone colour is dark enough to need it.
    function inkFor(hex) {
        const [r, g, b] = [1, 3, 5].map(index => parseInt(hex.slice(index, index + 2), 16) / 255).map(c => c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4);
        return 0.2126 * r + 0.7152 * g + 0.0722 * b < 0.3 ? '#fffefa' : '#121212';
    }

    // Built on the first open, so the photos and video only load when someone asks for the 3D ticket.
    function setup() {
        const M = root.Tickenshi;
        const $ = selector => document.querySelector(selector);
        const money = value => new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN', maximumFractionDigits: 0 }).format(value);
        const dialog = $('#ticket3d-dialog');
        const stage = $('#t3-stage');
        const scene = $('#t3-scene');
        const ticket = $('#t3-ticket');
        const image = $('#t3-image');
        const video = $('#t3-video');
        const motionButton = $('#t3-motion');
        const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
        let selected;
        try { selected = photo(localStorage.getItem(PHOTO_KEY)).id; } catch { selected = PHOTOS[0].id; }

        for (const item of PHOTOS) {
            const label = document.createElement('label');
            label.className = `t3-photo${item.type === 'doodle' ? ' is-doodle' : ''}`; label.title = item.label;
            const input = document.createElement('input');
            input.type = 'radio'; input.name = 't3-photo'; input.value = item.id; input.checked = item.id === selected;
            const media = document.createElement(item.type === 'video' ? 'video' : 'img');
            if (item.type === 'video') { media.muted = true; media.playsInline = true; media.preload = 'metadata'; media.src = `${item.src}#t=2`; }
            else { media.alt = ''; media.decoding = 'async'; media.src = item.src; }
            media.setAttribute('aria-hidden', 'true');
            const caption = document.createElement('span'); caption.className = 't3-sr'; caption.textContent = item.label;
            label.append(input, media, caption);
            if (item.type === 'video') { const badge = document.createElement('span'); badge.className = 't3-photo-badge'; badge.setAttribute('aria-hidden', 'true'); badge.textContent = '▶'; label.append(badge); }
            $('#t3-photos').append(label);
        }
        ticket.querySelector('.t3-doodle').src = photo('doodle').src;

        function render(raw) {
            const data = M.clean(raw);
            const color = M.ZONES[data.zone]?.color || DEFAULT_COLOR;
            const values = {
                name: data.name || 'Tu nombre', zone: data.zone || '—', section: data.section || '—', row: data.row || '—', seat: data.seat || '—',
                price: data.price ? `${money(data.price)} MXN` : '—', code: data.name ? M.code(data) : 'FAN-KY · TU RECUERDO'
            };
            ticket.querySelectorAll('[data-field]').forEach(element => {
                element.textContent = values[element.dataset.field];
                if (element.dataset.field === 'zone') element.dataset.len = String(values.zone.length);
            });
            stage.style.setProperty('--t3-zone', color);
            stage.style.setProperty('--t3-zone-ink', inkFor(color));
            const widths = barcode(values.code);
            ticket.querySelectorAll('[data-barcode]').forEach(element => element.replaceChildren(...widths.map(width => {
                const bar = document.createElement('span'); bar.style.setProperty('--w', width); return bar;
            })));
            ticket.classList.toggle('is-complete', M.complete(data));
        }
        function syncVideo() {
            if (video.hidden) return;
            if (paused || !dialog.open || document.hidden) video.pause();
            else video.play().catch(() => {}); // Autoplay can be refused; the loaded frame stays visible.
        }
        function renderPhoto() {
            const item = photo(selected);
            const frame = $('#t3-window');
            frame.classList.toggle('is-doodle', item.type === 'doodle');
            frame.style.setProperty('--photo-pos', item.position);
            if (item.type === 'video') {
                image.hidden = true;
                if (video.getAttribute('src') !== item.src) video.src = item.src;
                video.hidden = false;
                syncVideo();
            } else {
                video.pause(); video.hidden = true;
                image.src = item.src; image.hidden = false;
            }
        }
        $('#t3-photos').addEventListener('change', event => {
            selected = photo(event.target.value).id;
            try { localStorage.setItem(PHOTO_KEY, selected); } catch { /* The choice still applies while the page is open. */ }
            renderPhoto();
        });

        // Rotation: an idle wobble, a hover tilt for mice, and drag/fling that settles on the nearest face.
        let paused = reducedMotion.matches;
        let base = 0, rx = -6, ry = -18;
        let drag = null, hover = null, frameId = 0, last = 0;
        function target(now) {
            if (hover) return [-hover.y * 14, base + hover.x * 26];
            if (paused) return [-5, base - 16];
            return [-6 + Math.sin(now / 2300) * 5, base + Math.sin(now / 1500) * 26];
        }
        function apply() {
            const radians = ry * Math.PI / 180;
            ticket.style.setProperty('--rx', `${rx.toFixed(2)}deg`);
            ticket.style.setProperty('--ry', `${ry.toFixed(2)}deg`);
            stage.style.setProperty('--tilt-x', Math.sin(radians).toFixed(3));
            stage.style.setProperty('--tilt-y', (rx / 30).toFixed(3));
            stage.style.setProperty('--spread', (0.3 + 0.7 * Math.abs(Math.cos(radians))).toFixed(3));
        }
        function frame(now) {
            if (!dialog.open) { frameId = 0; last = 0; return; }
            const dt = Math.min(64, last ? now - last : 16);
            last = now;
            const [tx, ty] = target(now);
            if (!drag) {
                const k = reducedMotion.matches ? 1 : 1 - Math.exp(-dt / 140);
                rx += (tx - rx) * k; ry += (ty - ry) * k;
            }
            apply();
            if (!drag && (paused || hover) && Math.abs(tx - rx) + Math.abs(ty - ry) < 0.05) { frameId = 0; last = 0; return; }
            frameId = requestAnimationFrame(frame);
        }
        function kick() { if (!frameId) frameId = requestAnimationFrame(frame); }
        function flip(direction = 1) { base += 180 * direction; kick(); }
        scene.addEventListener('pointerdown', event => {
            if (event.button !== 0) return;
            drag = { id: event.pointerId, x: event.clientX, y: event.clientY, rx, ry, lastX: event.clientX, lastT: event.timeStamp, velocity: 0, moved: false };
            scene.setPointerCapture(event.pointerId);
            kick();
        });
        scene.addEventListener('pointermove', event => {
            if (drag && event.pointerId === drag.id) {
                const dx = event.clientX - drag.x, dy = event.clientY - drag.y;
                if (!drag.moved && Math.abs(dx) + Math.abs(dy) > 5) { drag.moved = true; scene.classList.add('is-dragging'); }
                ry = drag.ry + dx * 0.5;
                rx = Math.max(-40, Math.min(40, drag.rx - dy * 0.3));
                const dt = event.timeStamp - drag.lastT;
                if (dt > 0) drag.velocity = (event.clientX - drag.lastX) * 0.5 / dt;
                drag.lastX = event.clientX; drag.lastT = event.timeStamp;
            } else if (!drag && event.pointerType === 'mouse') {
                const box = scene.getBoundingClientRect();
                hover = { x: (event.clientX - box.left) / box.width * 2 - 1, y: (event.clientY - box.top) / box.height * 2 - 1 };
                kick();
            }
        });
        function release(event) {
            if (!drag || event.pointerId !== drag.id) return;
            const { moved, velocity } = drag;
            drag = null;
            scene.classList.remove('is-dragging');
            if (moved) base = Math.round((ry + Math.max(-180, Math.min(180, velocity * 160))) / 180) * 180; // A fling adds at most one flip.
            else if (event.type === 'pointerup') base += 180; // A tap or click flips.
            kick();
        }
        scene.addEventListener('pointerup', release);
        scene.addEventListener('pointercancel', release);
        scene.addEventListener('pointerleave', () => { if (hover) { hover = null; kick(); } });
        scene.addEventListener('keydown', event => {
            if (event.key === 'Enter' || event.key === ' ' || event.key === 'ArrowRight') flip(1);
            else if (event.key === 'ArrowLeft') flip(-1);
            else return;
            event.preventDefault();
        });
        $('#t3-flip').addEventListener('click', () => flip(1));
        function setPaused(value) { paused = value; motionButton.setAttribute('aria-pressed', String(paused)); syncVideo(); kick(); }
        motionButton.addEventListener('click', () => setPaused(!paused));
        reducedMotion.addEventListener('change', () => setPaused(reducedMotion.matches));
        document.addEventListener('visibilitychange', syncVideo);
        dialog.addEventListener('close', () => { video.pause(); hover = null; drag = null; });

        return {
            show(data) {
                render(data);
                base = 0; rx = -6; ry = -18;
                apply();
                dialog.showModal();
                renderPhoto(); setPaused(paused);
            }
        };
    }
    let view;
    function open(data) { (view ||= setup()).show(data); }

    const api = { PHOTOS, photo, barcode, inkFor, open };
    if (typeof module !== 'undefined' && module.exports) module.exports = api;
    else root.TickenshiTicket3D = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
